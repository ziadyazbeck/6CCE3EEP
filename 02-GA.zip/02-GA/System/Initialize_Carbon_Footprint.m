%The initialization function for the carbon footprint of each energy source
%that will be used within the simulations:

%Accessing the required global variables:
global System

%Define the different Energy Sources carbon footprint:
System.Initial.Carbon_FootPrint.Oil = 0.475;  %The footprint of oil
System.Initial.Carbon_FootPrint.Nat_gas = 0.038;  %The footprint of natural gas
System.Initial.Carbon_FootPrint.Coal = 1.394;  %The footprint of coal
System.Initial.Carbon_FootPrint.Elect = 0.06;  %The footprint of electricity
System.Initial.Carbon_FootPrint.Bio = 0.391;  %The footprint of bio-mass

%Note that the footprint is the same for the energy source, thus, the
%footprint value would be used for the same energy source regardless of the
%interval that is being considered in the study.