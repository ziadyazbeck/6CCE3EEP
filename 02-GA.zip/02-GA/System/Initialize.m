%The main initialization function responsible for initializing all the
%different dimensions of the simulation:

%declare/initialize the global variables that will be used:
evalin('base',' global System Optimization Calculations');
global System;  %access global variables.

%The main initialization script:
disp('The Program is initialized ...');
disp('   ');
Initialize_Energy_Sources();  %initialize the values of the different energy sources
Initialize_Carbon_Footprint();  %initialize the carbon footprint of energy sources
Initialize_Cost();  %initialize the cost of different energy sources
Initialize_Targets();  %Targets to be achieved by solving this optimization problem
Initialize_Weights();  %Weights of each target to be achieved by this optimization problem

%Take a copy of the initial system as a current system:
System.Current = System.Initial;