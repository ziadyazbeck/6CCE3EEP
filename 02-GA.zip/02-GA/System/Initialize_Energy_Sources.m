%The initialization function for the number of BOE from each energy source
%that will be used within the simulations:

%Accessing the required global variables:
global System

%Define the upperbound and lowerbound percentages for each source:
%==================================================================
Oil_UB_percentage = 1.2;        Oil_LB_percentage = 0.8;  %values from the nominal value
Nat_gas_UB_percentage = 1.5;  Nat_gas_LB_percentage = 1;  %values from the nominal value
Coal_UB_percentage = 1;       Coal_LB_percentage = 0.6;  %values from the nominal value
Elect_UB_percentage = 1.6;    Elect_LB_percentage = 1;  %values from the nominal value
Bio_UB_percentage = 1.4;      Bio_LB_percentage = 1;  %values from the nominal value


%Define the different Energy Sources counts:
%================================================
%start initialization for the 2022 interval:
%---------------------------------------------
System.Initial.Energy_Source_Count.Oil_22 = 340;  %The count of BOE from oil
System.Initial.Energy_Source_Count.Nat_gas_22 = 236;  %The count of BOE from natural gas
System.Initial.Energy_Source_Count.Coal_22 = 5;  %The count of BOE from coal
System.Initial.Energy_Source_Count.Elect_22 = 129;  %The count of BOE from electricity
System.Initial.Energy_Source_Count.Bio_22 = 128;  %The count of BOE from bio-mass

%start initialization for the 2025 interval:
%---------------------------------------------
System.Initial.Energy_Source_Count.Oil_25 = 331;  %The count of BOE from oil
System.Initial.Energy_Source_Count.Nat_gas_25 = 243;  %The count of BOE from natural gas
System.Initial.Energy_Source_Count.Coal_25 = 4;  %The count of BOE from coal
System.Initial.Energy_Source_Count.Elect_25 = 138;  %The count of BOE from electricity
System.Initial.Energy_Source_Count.Bio_25 = 124;  %The count of BOE from bio-mass

%start initialization for the 2030 interval:
%---------------------------------------------
System.Initial.Energy_Source_Count.Oil_30 = 322;  %The count of BOE from oil
System.Initial.Energy_Source_Count.Nat_gas_30 = 250;  %The count of BOE from natural gas
System.Initial.Energy_Source_Count.Coal_30 = 3;  %The count of BOE from coal
System.Initial.Energy_Source_Count.Elect_30 = 148;  %The count of BOE from electricity
System.Initial.Energy_Source_Count.Bio_30 = 120;  %The count of BOE from bio-mass

%Ranges:
%----------
System.Initial.Energy_Source_Count.Range.Oil_22_max = Oil_UB_percentage*System.Initial.Energy_Source_Count.Oil_22;  %max value
System.Initial.Energy_Source_Count.Range.Oil_22_min = Oil_LB_percentage*System.Initial.Energy_Source_Count.Oil_22;  %min value
System.Initial.Energy_Source_Count.Range.Oil_25_max = Oil_UB_percentage*System.Initial.Energy_Source_Count.Oil_25;  %max value
System.Initial.Energy_Source_Count.Range.Oil_25_min = Oil_LB_percentage*System.Initial.Energy_Source_Count.Oil_25;  %min value
System.Initial.Energy_Source_Count.Range.Oil_30_max = Oil_UB_percentage*System.Initial.Energy_Source_Count.Oil_30;  %max value
System.Initial.Energy_Source_Count.Range.Oil_30_min = Oil_LB_percentage*System.Initial.Energy_Source_Count.Oil_30;  %min value

System.Initial.Energy_Source_Count.Range.Nat_gas_22_max = Nat_gas_UB_percentage*System.Initial.Energy_Source_Count.Nat_gas_22;  %max value
System.Initial.Energy_Source_Count.Range.Nat_gas_22_min = Nat_gas_LB_percentage*System.Initial.Energy_Source_Count.Nat_gas_22;  %min valu
System.Initial.Energy_Source_Count.Range.Nat_gas_25_max = Nat_gas_UB_percentage*System.Initial.Energy_Source_Count.Nat_gas_25;  %max value
System.Initial.Energy_Source_Count.Range.Nat_gas_25_min = Nat_gas_LB_percentage*System.Initial.Energy_Source_Count.Nat_gas_25;  %min value
System.Initial.Energy_Source_Count.Range.Nat_gas_30_max = Nat_gas_UB_percentage*System.Initial.Energy_Source_Count.Nat_gas_30;  %max value
System.Initial.Energy_Source_Count.Range.Nat_gas_30_min = Nat_gas_LB_percentage*System.Initial.Energy_Source_Count.Nat_gas_30;  %min value

System.Initial.Energy_Source_Count.Range.Coal_22_max = Coal_UB_percentage*System.Initial.Energy_Source_Count.Coal_22;  %max value
System.Initial.Energy_Source_Count.Range.Coal_22_min = Coal_LB_percentage*System.Initial.Energy_Source_Count.Coal_22;  %min value
System.Initial.Energy_Source_Count.Range.Coal_25_max = Coal_UB_percentage*System.Initial.Energy_Source_Count.Coal_25;  %max value
System.Initial.Energy_Source_Count.Range.Coal_25_min = Coal_LB_percentage*System.Initial.Energy_Source_Count.Coal_25;  %min value
System.Initial.Energy_Source_Count.Range.Coal_30_max = Coal_UB_percentage*System.Initial.Energy_Source_Count.Coal_30;  %max value
System.Initial.Energy_Source_Count.Range.Coal_30_min = Coal_LB_percentage*System.Initial.Energy_Source_Count.Coal_30;  %min value

System.Initial.Energy_Source_Count.Range.Elect_22_max = Elect_UB_percentage*System.Initial.Energy_Source_Count.Elect_22;  %max value
System.Initial.Energy_Source_Count.Range.Elect_22_min = Elect_LB_percentage*System.Initial.Energy_Source_Count.Elect_22;  %min value
System.Initial.Energy_Source_Count.Range.Elect_25_max = Elect_UB_percentage*System.Initial.Energy_Source_Count.Elect_25;  %max value
System.Initial.Energy_Source_Count.Range.Elect_25_min = Elect_LB_percentage*System.Initial.Energy_Source_Count.Elect_25;  %min value
System.Initial.Energy_Source_Count.Range.Elect_30_max = Elect_UB_percentage*System.Initial.Energy_Source_Count.Elect_30;  %max value
System.Initial.Energy_Source_Count.Range.Elect_30_min = Elect_LB_percentage*System.Initial.Energy_Source_Count.Elect_30;  %min value

System.Initial.Energy_Source_Count.Range.Bio_22_max = Bio_UB_percentage*System.Initial.Energy_Source_Count.Bio_22;  %max value
System.Initial.Energy_Source_Count.Range.Bio_22_min = Bio_LB_percentage*System.Initial.Energy_Source_Count.Bio_22;  %min value
System.Initial.Energy_Source_Count.Range.Bio_25_max = Bio_UB_percentage*System.Initial.Energy_Source_Count.Bio_25;  %max value
System.Initial.Energy_Source_Count.Range.Bio_25_min = Bio_LB_percentage*System.Initial.Energy_Source_Count.Bio_25;  %min value
System.Initial.Energy_Source_Count.Range.Bio_30_max = Bio_UB_percentage*System.Initial.Energy_Source_Count.Bio_30;  %max value
System.Initial.Energy_Source_Count.Range.Bio_30_min = Bio_LB_percentage*System.Initial.Energy_Source_Count.Bio_30;  %min value

%cleaning up:
%==============
clear Oil_UB_percentage Oil_LB_percentage
clear Nat_gas_UB_percentage Nat_gas_LB_percentage
clear Coal_UB_percentage Coal_LB_percentage
clear Elect_UB_percentage Elect_LB_percentage
clear Bio_UB_percentage Bio_LB_percentage