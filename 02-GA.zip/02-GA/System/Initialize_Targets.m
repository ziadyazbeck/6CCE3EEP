%The initialization function for the targets to be achieved by this
%optimization problem and will be used within the simulations:

%Accessing the required global variables:
global System

%Define the different Targets:
System.Initial.Targets.Target_Carbon_FP_22 = 320;  %The Target Carbon FP for this interval
System.Initial.Targets.Target_Carbon_FP_25 = 265;  %The Target Carbon FP for this interval
System.Initial.Targets.Target_Carbon_FP_30 = 225;  %The Target Carbon FP for this interval

System.Initial.Targets.Target_Cost_22 = 130500;  %The Target Cost for this interval
System.Initial.Targets.Target_Cost_25 = 150500;  %The Target Cost for this interval
System.Initial.Targets.Target_Cost_30 = 192100;  %The Target Cost for this interval

System.Initial.Targets.Target_Energy_22 = 1942;  %The Target Energy Provided for this interval
System.Initial.Targets.Target_Energy_25 = 2061;  %The Target Energy Provided for this interval
System.Initial.Targets.Target_Energy_30 = 2389;  %The Target Energy Provided for this interval