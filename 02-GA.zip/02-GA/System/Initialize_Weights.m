%The initialization function for the weights of the targets to be achieved by this
%optimization problem and will be used within the simulations:

%Accessing the required global variables:
global System

%Define the different Targets:
System.Initial.Weights.Weight_Carbon_FP_22 = 0;  %The weight of Target Carbon FP for this interval
System.Initial.Weights.Weight_Carbon_FP_25 = 0;  %The weight of Target Carbon FP for this interval
System.Initial.Weights.Weight_Carbon_FP_30 = 0;  %The weight of Target Carbon FP for this interval

System.Initial.Weights.Weight_Cost_22 = 0;  %The weight of Target Cost for this interval
System.Initial.Weights.Weight_Cost_25 = 0;  %The weight of Target Cost for this interval
System.Initial.Weights.Weight_Cost_30 = 0;  %The weight of Target Cost for this interval

System.Initial.Weights.Weight_Energy_22 = 5;  %The weight of Target Energy Provided for this interval
System.Initial.Weights.Weight_Energy_25 = 3;  %The weight of Target Energy Provided for this interval
System.Initial.Weights.Weight_Energy_30 = 2;  %The weight of Target Energy Provided for this interval