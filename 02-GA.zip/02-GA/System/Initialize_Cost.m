%The initialization function for the cost of each energy source
%that will be used within the simulations:

%Accessing the required global variables:
global System

%Define the different Energy Sources carbon footprint:
%start initialization for the 2022 interval:
System.Initial.Cost.Oil_22 = 65;  %The Cost of oil
System.Initial.Cost.Nat_gas_22 = 238;  %The Cost of natural gas
System.Initial.Cost.Coal_22 = 440;  %The Cost of coal
System.Initial.Cost.Elect_22 = 578;  %The Cost of electricity
System.Initial.Cost.Bio_22 = 59.5;  %The Cost of bio-mass

%start initialization for the 2025 interval:
System.Initial.Cost.Oil_25 = 75.2;  %The Cost of oil
System.Initial.Cost.Nat_gas_25 = 275.5;  %The Cost of natural gas
System.Initial.Cost.Coal_25 = 509.4;  %The Cost of coal
System.Initial.Cost.Elect_25 = 669.1;  %The Cost of electricity
System.Initial.Cost.Bio_25 = 68.9;  %The Cost of bio-mass

%start initialization for the 2030 interval:
System.Initial.Cost.Oil_30 = 96;  %The Cost of oil
System.Initial.Cost.Nat_gas_30 = 351.6;  %The Cost of natural gas
System.Initial.Cost.Coal_30 = 650.1;  %The Cost of coal
System.Initial.Cost.Elect_30 = 854;  %The Cost of electricity
System.Initial.Cost.Bio_30 = 87.9;  %The Cost of bio-mass