%Function dedicated to initialize the initial population to be used in the
%Genetic Algorithm in its calculations:
function GA_init_pop()

%Accessing the needed global variables:
global Optimization System Calculations

%Access the needed parameters:
Pop_size = Optimization.GA.Params.Pop_size;  %read the number of chromosomes in the pop size
Num_var = Optimization.GA.Params.Num_var;   %Number of decision variables

%Loading the boundaries for the decision variables:
Oil_22_max = System.Current.Energy_Source_Count.Range.Oil_22_max;
Oil_22_min = System.Current.Energy_Source_Count.Range.Oil_22_min;
Nat_gas_22_max = System.Current.Energy_Source_Count.Range.Nat_gas_22_max;
Nat_gas_22_min = System.Current.Energy_Source_Count.Range.Nat_gas_22_min;
Coal_22_max = System.Current.Energy_Source_Count.Range.Coal_22_max;
Coal_22_min = System.Current.Energy_Source_Count.Range.Coal_22_min;
Elect_22_max = System.Current.Energy_Source_Count.Range.Elect_22_max;
Elect_22_min = System.Current.Energy_Source_Count.Range.Elect_22_min;
Bio_22_max = System.Current.Energy_Source_Count.Range.Bio_22_max;
Bio_22_min = System.Current.Energy_Source_Count.Range.Bio_22_min;

Oil_25_max = System.Current.Energy_Source_Count.Range.Oil_25_max;
Oil_25_min = System.Current.Energy_Source_Count.Range.Oil_25_min;
Nat_gas_25_max = System.Current.Energy_Source_Count.Range.Nat_gas_25_max;
Nat_gas_25_min = System.Current.Energy_Source_Count.Range.Nat_gas_25_min;
Coal_25_max = System.Current.Energy_Source_Count.Range.Coal_25_max;
Coal_25_min = System.Current.Energy_Source_Count.Range.Coal_25_min;
Elect_25_max = System.Current.Energy_Source_Count.Range.Elect_25_max;
Elect_25_min = System.Current.Energy_Source_Count.Range.Elect_25_min;
Bio_25_max = System.Current.Energy_Source_Count.Range.Bio_25_max;
Bio_25_min = System.Current.Energy_Source_Count.Range.Bio_25_min;

Oil_30_max = System.Current.Energy_Source_Count.Range.Oil_30_max;
Oil_30_min = System.Current.Energy_Source_Count.Range.Oil_30_min;
Nat_gas_30_max = System.Current.Energy_Source_Count.Range.Nat_gas_30_max;
Nat_gas_30_min = System.Current.Energy_Source_Count.Range.Nat_gas_30_min;
Coal_30_max = System.Current.Energy_Source_Count.Range.Coal_30_max;
Coal_30_min = System.Current.Energy_Source_Count.Range.Coal_30_min;
Elect_30_max = System.Current.Energy_Source_Count.Range.Elect_30_max;
Elect_30_min = System.Current.Energy_Source_Count.Range.Elect_30_min;
Bio_30_max = System.Current.Energy_Source_Count.Range.Bio_30_max;
Bio_30_min = System.Current.Energy_Source_Count.Range.Bio_30_min;

%Calculating the range for each decision variable:
Oil_22_range = Oil_22_max - Oil_22_min;
Nat_gas_22_range = Nat_gas_22_max - Nat_gas_22_min;
Coal_22_range = Coal_22_max - Coal_22_min;
Elect_22_range = Elect_22_max - Elect_22_min;
Bio_22_range = Bio_22_max - Bio_22_min;

Oil_25_range = Oil_25_max - Oil_25_min;
Nat_gas_25_range = Nat_gas_25_max - Nat_gas_25_min;
Coal_25_range = Coal_25_max - Coal_25_min;
Elect_25_range = Elect_25_max - Elect_25_min;
Bio_25_range = Bio_25_max - Bio_25_min;

Oil_30_range = Oil_30_max - Oil_30_min;
Nat_gas_30_range = Nat_gas_30_max - Nat_gas_30_min;
Coal_30_range = Coal_30_max - Coal_30_min;
Elect_30_range = Elect_30_max - Elect_30_min;
Bio_30_range = Bio_30_max - Bio_30_min;

%Initialize an empty cell to hold the Boundaries of decision variables:
Boundaries = cell(4,Num_var+1);
Boundaries{1,1} = ' '; Boundaries{1,2} = 'Oil_22'; Boundaries{1,3} = 'Nat_gas_22';
Boundaries{1,4} = 'Coal_22'; Boundaries{1,5} = 'Elect_22'; Boundaries{1,6} = 'Bio_22';
Boundaries{1,7} = 'Oil_25'; Boundaries{1,8} = 'Nat_gas_25';
Boundaries{1,9} = 'Coal_25'; Boundaries{1,10} = 'Elect_25'; Boundaries{1,11} = 'Bio_25';
Boundaries{1,12} = 'Oil_30'; Boundaries{1,13} = 'Nat_gas_30';
Boundaries{1,14} = 'Coal_30'; Boundaries{1,15} = 'Elect_30'; Boundaries{1,16} = 'Bio_30';
Boundaries{2,1} = 'Maximum'; Boundaries{3,1} = 'Minimum'; Boundaries{4,1} = 'Range';
%saving the values:
Boundaries{2,2} = Oil_22_max; Boundaries{3,2} = Oil_22_min; Boundaries{4,2} = Oil_22_range;
Boundaries{2,3} = Nat_gas_22_max; Boundaries{3,3} = Nat_gas_22_min; Boundaries{4,3} = Nat_gas_22_range;
Boundaries{2,4} = Coal_22_max; Boundaries{3,4} = Coal_22_min; Boundaries{4,4} = Coal_22_range;
Boundaries{2,5} = Elect_22_max; Boundaries{3,5} = Elect_22_min; Boundaries{4,5} = Elect_22_range;
Boundaries{2,6} = Bio_22_max; Boundaries{3,6} = Bio_22_min; Boundaries{4,6} = Bio_22_range;

Boundaries{2,7} = Oil_25_max; Boundaries{3,7} = Oil_25_min; Boundaries{4,7} = Oil_25_range;
Boundaries{2,8} = Nat_gas_25_max; Boundaries{3,8} = Nat_gas_25_min; Boundaries{4,8} = Nat_gas_25_range;
Boundaries{2,9} = Coal_25_max; Boundaries{3,9} = Coal_25_min; Boundaries{4,9} = Coal_25_range;
Boundaries{2,10} = Elect_25_max; Boundaries{3,10} = Elect_25_min; Boundaries{4,10} = Elect_25_range;
Boundaries{2,11} = Bio_25_max; Boundaries{3,11} = Bio_25_min; Boundaries{4,11} = Bio_25_range;

Boundaries{2,12} = Oil_30_max; Boundaries{3,12} = Oil_30_min; Boundaries{4,12} = Oil_30_range;
Boundaries{2,13} = Nat_gas_30_max; Boundaries{3,13} = Nat_gas_30_min; Boundaries{4,13} = Nat_gas_30_range;
Boundaries{2,14} = Coal_30_max; Boundaries{3,14} = Coal_30_min; Boundaries{4,14} = Coal_30_range;
Boundaries{2,15} = Elect_30_max; Boundaries{3,15} = Elect_30_min; Boundaries{4,15} = Elect_30_range;
Boundaries{2,16} = Bio_30_max; Boundaries{3,16} = Bio_30_min; Boundaries{4,16} = Bio_30_range;

%Saving the boundaries of decision variables:
Optimization.GA.Boundaries = Boundaries;

%Initialize the empty population
pop_init = cell(1+Pop_size,Num_var);   %creating an empty matrix for init population
pop_init{1,1} = 'Oil_22';
pop_init{1,2} = 'Nat_gas_22';
pop_init{1,3} = 'Coal_22';
pop_init{1,4} = 'Elect_22';
pop_init{1,5} = 'Bio_22';
pop_init{1,6} = 'Oil_25';
pop_init{1,7} = 'Nat_gas_25';
pop_init{1,8} = 'Coal_25';
pop_init{1,9} = 'Elect_25';
pop_init{1,10} = 'Bio_25';
pop_init{1,11} = 'Oil_30';
pop_init{1,12} = 'Nat_gas_30';
pop_init{1,13} = 'Coal_30';
pop_init{1,14} = 'Elect_30';
pop_init{1,15} = 'Bio_30';

%Initializing the population randomly:
for i = 2:size(pop_init,1)  %For all the rows
    oil_22 = Oil_22_min + rand * Oil_22_range;
    nat_gas_22 = Nat_gas_22_min + rand * Nat_gas_22_range;
    coal_22 = Coal_22_min + rand * Coal_22_range;
    elect_22 = Elect_22_min + rand * Elect_22_range;
    bio_22 = Bio_22_min + rand * Bio_22_range;
    
    oil_25 = Oil_25_min + rand * Oil_25_range;
    nat_gas_25 = Nat_gas_25_min + rand * Nat_gas_25_range;
    coal_25 = Coal_25_min + rand * Coal_25_range;
    elect_25 = Elect_25_min + rand * Elect_25_range;
    bio_25 = Bio_25_min + rand * Bio_25_range;
    
    oil_30 = Oil_30_min + rand * Oil_30_range;
    nat_gas_30 = Nat_gas_30_min + rand * Nat_gas_30_range;
    coal_30 = Coal_30_min + rand * Coal_30_range;
    elect_30 = Elect_30_min + rand * Elect_30_range;
    bio_30 = Bio_30_min + rand * Bio_30_range;
    
    pop_init(i,1:Num_var) = {oil_22, nat_gas_22, coal_22, elect_22, bio_22,...
                             oil_25, nat_gas_25, coal_25, elect_25, bio_25,...
                             oil_30, nat_gas_30, coal_30, elect_30, bio_30};
end

%Calculating the cost of the initial population members:
pop_init{1,16} = 'Carbon_FP_22';
pop_init{1,17} = 'Carbon_FP_25';
pop_init{1,18} = 'Carbon_FP_30';
pop_init{1,19} = 'Cost_22';
pop_init{1,20} = 'Cost_25';
pop_init{1,21} = 'Cost_30';
pop_init{1,22} = 'Energy_22';
pop_init{1,23} = 'Energy_25';
pop_init{1,24} = 'Energy_30';

pop_init{1,25} = 'Cost_fcn';

for i=2:size(pop_init,1)  %for all the rows (members in population)
    %Update the current system parameters values with the current
    %population member values:
    System.Current.Energy_Source_Count.Oil_22 = pop_init{i,1};
    System.Current.Energy_Source_Count.Nat_gas_22 = pop_init{i,2};
    System.Current.Energy_Source_Count.Coal_22 = pop_init{i,3};
    System.Current.Energy_Source_Count.Elect_22 = pop_init{i,4};
    System.Current.Energy_Source_Count.Bio_22 = pop_init{i,5};
    
    System.Current.Energy_Source_Count.Oil_25 = pop_init{i,6};
    System.Current.Energy_Source_Count.Nat_gas_25 = pop_init{i,7};
    System.Current.Energy_Source_Count.Coal_25 = pop_init{i,8};
    System.Current.Energy_Source_Count.Elect_25 = pop_init{i,9};
    System.Current.Energy_Source_Count.Bio_25 = pop_init{i,10};
    
    System.Current.Energy_Source_Count.Oil_30 = pop_init{i,11};
    System.Current.Energy_Source_Count.Nat_gas_30 = pop_init{i,12};
    System.Current.Energy_Source_Count.Coal_30 = pop_init{i,13};
    System.Current.Energy_Source_Count.Elect_30 = pop_init{i,14};
    System.Current.Energy_Source_Count.Bio_30 = pop_init{i,15};
       
    Calculate_all();  %Calculate all values based on this member values:
    
    %Retrieve the values of calculations:
    Carbon_FP_22 = Calculations.Carbon_FP_22;  % Carbon footprint for this interval
    Carbon_FP_25 = Calculations.Carbon_FP_25;  % Carbon footprint for this interval
    Carbon_FP_30 = Calculations.Carbon_FP_30;  % Carbon footprint for this interval
    
    Cost_22 = Calculations.Cost_22;  % Cost for this interval
    Cost_25 = Calculations.Cost_25;  % Cost for this interval
    Cost_30 = Calculations.Cost_30;  % Cost for this interval
    
    Energy_22 = Calculations.Energy_22;  % Energy for this interval
    Energy_25 = Calculations.Energy_25;  % Energy for this interval
    Energy_30 = Calculations.Energy_30;  % Energy for this interval
       
    pop_init{i,16} = Carbon_FP_22;
    pop_init{i,17} = Carbon_FP_25;
    pop_init{i,18} = Carbon_FP_30;
    
    pop_init{i,19} = Cost_22;
    pop_init{i,20} = Cost_25;
    pop_init{i,21} = Cost_30;
    
    pop_init{i,22} = Energy_22;
    pop_init{i,23} = Energy_25;
    pop_init{i,24} = Energy_30;
    
    %load the targets for the calculations of the objective function:
    carbon_fp_22_targ = System.Current.Targets.Target_Carbon_FP_22;
    carbon_fp_25_targ = System.Current.Targets.Target_Carbon_FP_25;
    carbon_fp_30_targ = System.Current.Targets.Target_Carbon_FP_30;
    
    cost_22_targ = System.Current.Targets.Target_Cost_22;
    cost_25_targ = System.Current.Targets.Target_Cost_25;
    cost_30_targ = System.Current.Targets.Target_Cost_30;
    
    energy_22_targ = System.Current.Targets.Target_Energy_22;
    energy_25_targ = System.Current.Targets.Target_Energy_25;
    energy_30_targ = System.Current.Targets.Target_Energy_30;
    
    %load the weights for the calculations of the objective function:
    carbon_fp_22_weight = System.Current.Weights.Weight_Carbon_FP_22;
    carbon_fp_25_weight = System.Current.Weights.Weight_Carbon_FP_25;
    carbon_fp_30_weight = System.Current.Weights.Weight_Carbon_FP_30;
    
    cost_22_weight = System.Current.Weights.Weight_Cost_22;
    cost_25_weight= System.Current.Weights.Weight_Cost_25;
    cost_30_weight = System.Current.Weights.Weight_Cost_30;
    
    energy_22_weight = System.Current.Weights.Weight_Energy_22;
    energy_25_weight = System.Current.Weights.Weight_Energy_25;
    energy_30_weight = System.Current.Weights.Weight_Energy_30;
      
    %Calculate the Objective function Cost:
    %========================================
    Cost = carbon_fp_22_weight * ((Carbon_FP_22 - carbon_fp_22_targ) / carbon_fp_22_targ) + ...
           carbon_fp_25_weight * ((Carbon_FP_25 - carbon_fp_25_targ) / carbon_fp_25_targ) + ...
           carbon_fp_30_weight * ((Carbon_FP_30 - carbon_fp_30_targ) / carbon_fp_30_targ) + ...
           cost_22_weight * ((Cost_22 - cost_22_targ) / cost_22_targ) + ...
           cost_25_weight * ((Cost_25 - cost_25_targ) / cost_25_targ) + ...
           cost_30_weight * ((Cost_30 - cost_30_targ) / cost_30_targ) + ...
           energy_22_weight * ((energy_22_targ - Energy_22) / energy_22_targ) + ...
           energy_25_weight * ((energy_25_targ - Energy_25) / energy_25_targ) + ...
           energy_30_weight * ((energy_30_targ - Energy_30) / energy_30_targ);
       
    pop_init{i,25} = Cost;
end

%storing the randomly generated population:
Optimization.GA.Population.Initial = pop_init;
Optimization.GA.Population.Current = pop_init;
end