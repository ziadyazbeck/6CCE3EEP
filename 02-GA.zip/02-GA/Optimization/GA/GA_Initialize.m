function GA_Initialize()
%Initialize the Genetic Algorithm (GA) and its parameters:

%Access the global variables:
global Optimization

%Define the different parameters of the Genetic Algorithm (GA):
Optimization.GA.Params.Elite_ratio = 0.1;   %Elitism ratio
Optimization.GA.Params.CO_ratio = 0.4;  %Cross Over ratio
Optimization.GA.Params.Mut_ratio = ...   %Mutation ratio 
    1 - Optimization.GA.Params.Elite_ratio - Optimization.GA.Params.CO_ratio;  
Optimization.GA.Params.Pop_size = 200;   %Population size
Optimization.GA.Params.Num_Gen = 2000;  %Maximum Number of generations
Optimization.GA.Params.Num_var = 15;  %The number of decision variables
Optimization.GA.Params.CO_alpha = 0.4;  %Alpha used in the cross over process
Optimization.GA.Params.Mut_noise = 0.5;  %percentage of noise added in Mutation process

end