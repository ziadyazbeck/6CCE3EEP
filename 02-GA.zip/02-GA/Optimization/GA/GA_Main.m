%function with the main core for the Genetic Algorithm (GA):
function GA_Main()

%The main functions for the GA:
GA_Initialize();
GA_init_pop();
GA_Evolve();
GA_Plot();
GA_Report();

end