%Function to plot the results of the GA:
function GA_Plot()
% close all
%Access the needed variables:
global Optimization

%Reading the required parameters;
Num_Gen = Optimization.GA.Params.Num_Gen;  %Number of generations needed
Elite = Optimization.GA.Elite;  %storing the elite values

%Starting plotting in a new figure,
figure(); %open a new figure
x_data = 0:1:Num_Gen;  %Creating the number of iterations variable
y_data = cell2mat(Elite(2:end,size(Elite,2)));  %reading the cost value
plot(x_data,y_data,'LineWidth',3);
xlabel('Number of Generation');
ylabel('Cost Function Value');
title('GA Objective Function Convergance Curve');
legend('Obj. fcn');
grid on
% ylim([0.06 0.12]);


end