function GA_Evolve()
%Function to evolve the GA population through iterations by applying the
%different operators of the Genetic Algorithm

%Accessing the global variables needed:
global Optimization Calculations System

Num_Gen = Optimization.GA.Params.Num_Gen;  %Number of generations needed
Num_var = Optimization.GA.Params.Num_var;  %Number of variables optimized
Pop_size = Optimization.GA.Params.Pop_size;  %population size
Elite_ratio = Optimization.GA.Params.Elite_ratio;
CO_ratio = Optimization.GA.Params.CO_ratio;
num_elite = floor(Pop_size * Elite_ratio);  %num of elite members
num_cross_over = floor(Pop_size * CO_ratio);  %num of children by cross over
num_mutants = Pop_size - num_elite - num_cross_over;  %num of mutants in each generation
CO_alpha = Optimization.GA.Params.CO_alpha;  %alpha used in cross over operation
Mut_noise = Optimization.GA.Params.Mut_noise;  %Noise used in Mutation of members
Boundaries = Optimization.GA.Boundaries;  %Accessing the boundaries of the decision variables

%load the targets for the calculations of the objective function:
    carbon_fp_22_targ = System.Current.Targets.Target_Carbon_FP_22;
    carbon_fp_25_targ = System.Current.Targets.Target_Carbon_FP_25;
    carbon_fp_30_targ = System.Current.Targets.Target_Carbon_FP_30;
    
    cost_22_targ = System.Current.Targets.Target_Cost_22;
    cost_25_targ = System.Current.Targets.Target_Cost_25;
    cost_30_targ = System.Current.Targets.Target_Cost_30;
    
    energy_22_targ = System.Current.Targets.Target_Energy_22;
    energy_25_targ = System.Current.Targets.Target_Energy_25;
    energy_30_targ = System.Current.Targets.Target_Energy_30;
    
    %load the weights for the calculations of the objective function:
    carbon_fp_22_weight = System.Current.Weights.Weight_Carbon_FP_22;
    carbon_fp_25_weight = System.Current.Weights.Weight_Carbon_FP_25;
    carbon_fp_30_weight = System.Current.Weights.Weight_Carbon_FP_30;
    
    cost_22_weight = System.Current.Weights.Weight_Cost_22;
    cost_25_weight= System.Current.Weights.Weight_Cost_25;
    cost_30_weight = System.Current.Weights.Weight_Cost_30;
    
    energy_22_weight = System.Current.Weights.Weight_Energy_22;
    energy_25_weight = System.Current.Weights.Weight_Energy_25;
    energy_30_weight = System.Current.Weights.Weight_Energy_30;

%Initialize Variable to store the Elite accross generations:
Elite = cell(2+Num_Gen,Num_var+2);   %creating an empty matrix for init population
Elite{1,1} = 'Iteration No.';
Elite{1,2} = 'Oil_22';
Elite{1,3} = 'Nat_gas_22';
Elite{1,4} = 'Coal_22';
Elite{1,5} = 'Elect_22';
Elite{1,6} = 'Bio_22';
Elite{1,7} = 'Oil_25';
Elite{1,8} = 'Nat_gas_25';
Elite{1,9} = 'Coal_25';
Elite{1,10} = 'Elect_25';
Elite{1,11} = 'Bio_25';
Elite{1,12} = 'Oil_30';
Elite{1,13} = 'Nat_gas_30';
Elite{1,14} = 'Coal_30';
Elite{1,15} = 'Elect_30';
Elite{1,16} = 'Bio_30';
Elite{1,17} = 'Cost';

for i = 1:Num_Gen  %for all number of generations needed
    curr_pop = cell2mat(Optimization.GA.Population.Current(2:end,1:Num_var)); %reading current population
    curr_cost = cell2mat(Optimization.GA.Population.Current(2:end,25));  %reading current cost
    new_pop = zeros(size(curr_pop));  %initialize empty matrix for new generation
        
    %Sorting the current generation:
    [~,rank] = sort(curr_cost,'ascend');
    
    %Storing the Elite information:
    elite_num = rank(1,1);  %get the number of best element
    elite = curr_pop(elite_num,1:Num_var);
    Elite{i+1,1} = i-1;
    Elite{i+1,2} = elite(1,1);
    Elite{i+1,3} = elite(1,2);
    Elite{i+1,4} = elite(1,3);
    Elite{i+1,5} = elite(1,4);
    Elite{i+1,6} = elite(1,5);
    Elite{i+1,7} = elite(1,6);
    Elite{i+1,8} = elite(1,7);
    Elite{i+1,9} = elite(1,8);
    Elite{i+1,10} = elite(1,9);
    Elite{i+1,11} = elite(1,10);
    Elite{i+1,12} = elite(1,11);
    Elite{i+1,13} = elite(1,12);
    Elite{i+1,14} = elite(1,13);
    Elite{i+1,15} = elite(1,14);
    Elite{i+1,16} = elite(1,15);
    Elite{i+1,17} = curr_cost(elite_num,1);
    disp(['Current Generation Number is: ' num2str(i-1) ', Elite cost is: ' num2str(curr_cost(elite_num,1))]);

    %get the elites:
    if num_elite ~= 0
        for j = 1:num_elite  %for all needed number of elites
            rank_num = rank(j,1);  %get the number of best elements in their rank
            new_pop(j,:) = curr_pop(rank_num,1:Num_var);  
        end
    end
    
    %get the parents to do cross over (rule used for CO is selection of one
    %of the elites and a random member from the population):
    if num_cross_over ~= 0
        for j = 1:2:num_cross_over %for all needed number of children
            rand_elite = randi(num_elite);  %randomly select one of elites order
            rank_num = rank(rand_elite,1);  %get that elite number from the list
            parent_1 = curr_pop(rank_num,1:Num_var);  %Get the elite as parent 1
            rand_member = randi(Pop_size);  %random member from all the population
            parent_2 = curr_pop(rand_member,1:Num_var);  %get parent 2 from the list
            %do the cross-over process:
            child_1 = zeros(1,Num_var);  %initialize empty child 1
            child_2 = zeros(1,Num_var);  %initialize empty child 2
            for m = 1:Num_var
                child_1(1,m) = (CO_alpha * parent_1(1,m)) + ((1-CO_alpha) * parent_2(1,m));
                child_2(1,m) = ((1-CO_alpha) * parent_1(1,m)) + (CO_alpha * parent_2(1,m));
            end
            %saving newly created children:
            new_pop(num_elite + j,:) = child_1;   %saving 1st child
            new_pop(num_elite + j+1,:) = child_2;  %saving 2nd child
        end
    end
    
    if num_mutants ~= 0
        for j = 1:num_mutants
            %select the worst members:
            worst_rank = rank(Pop_size - j + 1,1);  %get the worst rank in sorting
            member = curr_pop(worst_rank,1:Num_var);  %get the worst member
            mutant = zeros(size(member));  %initialize the mutant member as zeros
            for m = 1:Num_var  %for all the variables
                mutant(1,m) = member(1,m) + ...
                    randi([-1,1]) * rand * Mut_noise * Boundaries{4,m+1};  %Addition of random noise to each variable
                %Feasibility check on boundaries:
                if mutant(1,m) > Boundaries{2,m+1};  mutant(1,m) = Boundaries{2,m+1}; end  
                if mutant(1,m) < Boundaries{3,m+1};  mutant(1,m) = Boundaries{3,m+1}; end  
            end
            %saving newly created mutants:
            new_pop(num_elite + num_cross_over + j,:) = mutant;   %saving the mutant
        end
    end   
    
    %Calculating the cost of each member in the new population:
    for j = 1:Pop_size  %for all the members in the population
        for m = 1:Num_var  %for all the variables
            Optimization.GA.Population.Current{j+1,m} = new_pop(j,m);
        end
        %Update the current system parameters values with the current
        %population member values:
        System.Current.Energy_Source_Count.Oil_22 = new_pop(j,1);
        System.Current.Energy_Source_Count.Nat_gas_22 = new_pop(j,2);
        System.Current.Energy_Source_Count.Coal_22 = new_pop(j,3);
        System.Current.Energy_Source_Count.Elect_22 = new_pop(j,4);
        System.Current.Energy_Source_Count.Bio_22 = new_pop(j,5);

        System.Current.Energy_Source_Count.Oil_25 = new_pop(j,6);
        System.Current.Energy_Source_Count.Nat_gas_25 = new_pop(j,7);
        System.Current.Energy_Source_Count.Coal_25 = new_pop(j,8);
        System.Current.Energy_Source_Count.Elect_25 = new_pop(j,9);
        System.Current.Energy_Source_Count.Bio_25 = new_pop(j,10);

        System.Current.Energy_Source_Count.Oil_30 = new_pop(j,11);
        System.Current.Energy_Source_Count.Nat_gas_30 = new_pop(j,12);
        System.Current.Energy_Source_Count.Coal_30 = new_pop(j,13);
        System.Current.Energy_Source_Count.Elect_30 = new_pop(j,14);
        System.Current.Energy_Source_Count.Bio_30 = new_pop(j,15);
        
        %Do the calculations:
        Calculate_all();  %Calculate all values based on this member values
        
        %Retrieve the values of calculations:
        Carbon_FP_22 = Calculations.Carbon_FP_22;  % Carbon footprint for this interval
        Carbon_FP_25 = Calculations.Carbon_FP_25;  % Carbon footprint for this interval
        Carbon_FP_30 = Calculations.Carbon_FP_30;  % Carbon footprint for this interval

        Cost_22 = Calculations.Cost_22;  % Cost for this interval
        Cost_25 = Calculations.Cost_25;  % Cost for this interval
        Cost_30 = Calculations.Cost_30;  % Cost for this interval

        Energy_22 = Calculations.Energy_22;  % Energy for this interval
        Energy_25 = Calculations.Energy_25;  % Energy for this interval
        Energy_30 = Calculations.Energy_30;  % Energy for this interval
        
        Optimization.GA.Population.Current{j+1,16} = Carbon_FP_22;
        Optimization.GA.Population.Current{j+1,17} = Carbon_FP_25;
        Optimization.GA.Population.Current{j+1,18} = Carbon_FP_30;
        Optimization.GA.Population.Current{j+1,19} = Cost_22;
        Optimization.GA.Population.Current{j+1,20} = Cost_25;
        Optimization.GA.Population.Current{j+1,21} = Cost_30;
        Optimization.GA.Population.Current{j+1,22} = Energy_22;
        Optimization.GA.Population.Current{j+1,23} = Energy_25;
        Optimization.GA.Population.Current{j+1,24} = Energy_30;
        
        %Calculate the Objective function Cost:
        %========================================
        Cost = carbon_fp_22_weight * ((Carbon_FP_22 - carbon_fp_22_targ) / carbon_fp_22_targ) + ...
               carbon_fp_25_weight * ((Carbon_FP_25 - carbon_fp_25_targ) / carbon_fp_25_targ) + ...
               carbon_fp_30_weight * ((Carbon_FP_30 - carbon_fp_30_targ) / carbon_fp_30_targ) + ...
               cost_22_weight * ((Cost_22 - cost_22_targ) / cost_22_targ) + ...
               cost_25_weight * ((Cost_25 - cost_25_targ) / cost_25_targ) + ...
               cost_30_weight * ((Cost_30 - cost_30_targ) / cost_30_targ) + ...
               energy_22_weight * ((energy_22_targ - Energy_22) / energy_22_targ) + ...
               energy_25_weight * ((energy_25_targ - Energy_25) / energy_25_targ) + ...
               energy_30_weight * ((energy_30_targ - Energy_30) / energy_30_targ);
        Optimization.GA.Population.Current{j+1,25} = Cost;
    end
end
%Storing the elite of the last generation:
curr_pop = cell2mat(Optimization.GA.Population.Current(2:end,1:Num_var)); %reading current population
curr_cost = cell2mat(Optimization.GA.Population.Current(2:end,25));  %reading current cost
%Sorting the current generation:
[~,rank] = sort(curr_cost,'ascend');
%Storing the Elite information:
elite_num = rank(1,1);  %get the number of best element
elite = curr_pop(elite_num,1:Num_var);
Elite{Num_Gen+2,1} = Num_Gen;
Elite{Num_Gen+2,2} = elite(1,1);
Elite{Num_Gen+2,3} = elite(1,2);
Elite{Num_Gen+2,4} = elite(1,3);
Elite{Num_Gen+2,5} = elite(1,4);
Elite{Num_Gen+2,6} = elite(1,5);
Elite{Num_Gen+2,7} = elite(1,6);
Elite{Num_Gen+2,8} = elite(1,7);
Elite{Num_Gen+2,9} = elite(1,8);
Elite{Num_Gen+2,10} = elite(1,9);
Elite{Num_Gen+2,11} = elite(1,10);
Elite{Num_Gen+2,12} = elite(1,11);
Elite{Num_Gen+2,13} = elite(1,12);
Elite{Num_Gen+2,14} = elite(1,13);
Elite{Num_Gen+2,15} = elite(1,14);
Elite{Num_Gen+2,16} = elite(1,15);
Elite{Num_Gen+2,17} = curr_cost(elite_num,1);

disp(['Current Generation Number is: ' num2str(Num_Gen) ', Elite cost is: ' num2str(curr_cost(elite_num,1))]);
Optimization.GA.Elite = Elite;  %storing the elite values
end