%Function to report the output of the GA optimization problem:
function GA_Report()

%Access the needed parameters:
global Optimization

%Displaying the results:
disp('   ');
disp('GA Optimization Finished...');
disp('Results are as follows: ');
disp('     ');
disp(['Oil 2022 is: ' num2str(Optimization.GA.Elite{end,2}) ' BOE']);
disp(['Nat. Gas 2022 is: ' num2str(Optimization.GA.Elite{end,3}) ' BOE']);
disp(['Coal 2022 is: ' num2str(Optimization.GA.Elite{end,4}) ' BOE']);
disp(['Electricity 2022 is: ' num2str(Optimization.GA.Elite{end,5}) ' BOE']);
disp(['Bio mass 2022 is: ' num2str(Optimization.GA.Elite{end,6}) ' BOE']);
disp(['Oil 2025 is: ' num2str(Optimization.GA.Elite{end,7}) ' BOE']);
disp(['Nat. Gas 2025 is: ' num2str(Optimization.GA.Elite{end,8}) ' BOE']);
disp(['Coal 2025 is: ' num2str(Optimization.GA.Elite{end,9}) ' BOE']);
disp(['Electricity 2025 is: ' num2str(Optimization.GA.Elite{end,10}) ' BOE']);
disp(['Bio mass 2025 is: ' num2str(Optimization.GA.Elite{end,11}) ' BOE']);
disp(['Oil 2030 is: ' num2str(Optimization.GA.Elite{end,12}) ' BOE']);
disp(['Nat. Gas 2030 is: ' num2str(Optimization.GA.Elite{end,13}) ' BOE']);
disp(['Coal 2030 is: ' num2str(Optimization.GA.Elite{end,14}) ' BOE']);
disp(['Electricity 2030 is: ' num2str(Optimization.GA.Elite{end,15}) ' BOE']);
disp(['Bio mass 2030 is: ' num2str(Optimization.GA.Elite{end,1}) ' BOE']);

disp('   ');
disp('Thank you for using our code... =)');
end