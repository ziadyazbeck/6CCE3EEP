%clean the coding environment before starting & adding needed directory:
clc, clear, close all, clear global
addpath(genpath(pwd)); %consider all sub-directories and their functions.

%The main code structure:
Initialize();
Calculate_all();
GA_Main();
