function Calc_Cost()
%A function responsible for calculation of cost for all available
%energy sources for further calculations later on:

%access the global variables required for calculations:
global System Calculations

%read the needed parameters:
Oil_22 = System.Current.Energy_Source_Count.Oil_22;
Nat_gas_22 = System.Current.Energy_Source_Count.Nat_gas_22;
Coal_22 = System.Current.Energy_Source_Count.Coal_22;
Elect_22 = System.Current.Energy_Source_Count.Elect_22;
Bio_22 = System.Current.Energy_Source_Count.Bio_22;

Oil_25 = System.Current.Energy_Source_Count.Oil_25;
Nat_gas_25 = System.Current.Energy_Source_Count.Nat_gas_25;
Coal_25 = System.Current.Energy_Source_Count.Coal_25;
Elect_25 = System.Current.Energy_Source_Count.Elect_25;
Bio_25 = System.Current.Energy_Source_Count.Bio_25;

Oil_30 = System.Current.Energy_Source_Count.Oil_30;
Nat_gas_30 = System.Current.Energy_Source_Count.Nat_gas_30;
Coal_30 = System.Current.Energy_Source_Count.Coal_30;
Elect_30 = System.Current.Energy_Source_Count.Elect_30;
Bio_30 = System.Current.Energy_Source_Count.Bio_30;

Oil_cost_22 = System.Current.Cost.Oil_22;
Nat_gas_cost_22 = System.Current.Cost.Nat_gas_22;
Coal_cost_22 = System.Current.Cost.Coal_22;
Elect_cost_22 = System.Current.Cost.Elect_22;
Bio_cost_22 = System.Current.Cost.Bio_22;

Oil_cost_25 = System.Current.Cost.Oil_25;
Nat_gas_cost_25 = System.Current.Cost.Nat_gas_25;
Coal_cost_25 = System.Current.Cost.Coal_25;
Elect_cost_25 = System.Current.Cost.Elect_25;
Bio_cost_25 = System.Current.Cost.Bio_25;

Oil_cost_30 = System.Current.Cost.Oil_30;
Nat_gas_cost_30 = System.Current.Cost.Nat_gas_30;
Coal_cost_30 = System.Current.Cost.Coal_30;
Elect_cost_30 = System.Current.Cost.Elect_30;
Bio_cost_30 = System.Current.Cost.Bio_30;

%Calculations:
Cost_22 = Oil_cost_22 * Oil_22 + Nat_gas_cost_22 * Nat_gas_22 + Coal_cost_22 * Coal_22 + ...
    Elect_cost_22 * Elect_22 + Bio_cost_22 * Bio_22;

Cost_25 = Oil_cost_25 * Oil_25 + Nat_gas_cost_25 * Nat_gas_25 + Coal_cost_25 * Coal_25 + ...
    Elect_cost_25 * Elect_25 + Bio_cost_25 * Bio_25;

Cost_30 = Oil_cost_30 * Oil_30 + Nat_gas_cost_30 * Nat_gas_30 + Coal_cost_30 * Coal_30 + ...
    Elect_cost_30 * Elect_30 + Bio_cost_30 * Bio_30;

%saving the results of calculations here:
Calculations.Cost_22 = Cost_22;
Calculations.Cost_25 = Cost_25;
Calculations.Cost_30 = Cost_30;

end