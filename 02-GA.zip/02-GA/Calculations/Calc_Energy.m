function Calc_Energy()
%A function responsible for calculation of energy provided for all available
%energy sources for further calculations later on:

%access the global variables required for calculations:
global System Calculations

%read the needed parameters:
Oil_22 = System.Current.Energy_Source_Count.Oil_22;
Nat_gas_22 = System.Current.Energy_Source_Count.Nat_gas_22;
Coal_22 = System.Current.Energy_Source_Count.Coal_22;
Elect_22 = System.Current.Energy_Source_Count.Elect_22;
Bio_22 = System.Current.Energy_Source_Count.Bio_22;

Oil_25 = System.Current.Energy_Source_Count.Oil_25;
Nat_gas_25 = System.Current.Energy_Source_Count.Nat_gas_25;
Coal_25 = System.Current.Energy_Source_Count.Coal_25;
Elect_25 = System.Current.Energy_Source_Count.Elect_25;
Bio_25 = System.Current.Energy_Source_Count.Bio_25;

Oil_30 = System.Current.Energy_Source_Count.Oil_30;
Nat_gas_30 = System.Current.Energy_Source_Count.Nat_gas_30;
Coal_30 = System.Current.Energy_Source_Count.Coal_30;
Elect_30 = System.Current.Energy_Source_Count.Elect_30;
Bio_30 = System.Current.Energy_Source_Count.Bio_30;

%Calculations:
Energy_22 = Oil_22 + Nat_gas_22 + Coal_22 + Elect_22 + Bio_22;
Energy_25 = Oil_25 + Nat_gas_25 + Coal_25 + Elect_25 + Bio_25;
Energy_30 = Oil_30 + Nat_gas_30 + Coal_30 + Elect_30 + Bio_30;

%saving the results of calculations here:
Calculations.Energy_22 = Energy_22;
Calculations.Energy_25 = Energy_25;
Calculations.Energy_30 = Energy_30;

end