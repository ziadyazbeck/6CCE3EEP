%Function with all calculations:
function Calculate_all()

%All Related calculations here:
Calc_Carbon_Footprint();
Calc_Cost();
Calc_Energy();

% disp('   ');

end